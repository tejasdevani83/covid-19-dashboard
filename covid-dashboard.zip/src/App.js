import React, { lazy, Suspense } from "react";
import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
const Dashboard = lazy(() => import("./Components/Dashboard"));

function App() {
  return (
    <div className="App">
      <header>
        <div className="conatainer header">Covid19 Dashboard</div>
      </header>
      <Suspense fallback={<div />}>
        <Dashboard />
      </Suspense>
    </div>
  );
}

export default App;
