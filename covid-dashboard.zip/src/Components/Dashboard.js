import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";

export default function Dashboard(props) {
  const [data, setData] = useState([]);
  useEffect(() => {
    axios.get(`https://api.covid19india.org/data.json`).then((response) => {
      let state_data = [];
      state_data.push(response.data);
      setData(state_data);
    });
  }, []);

  const header = ["State/UT", "Confirmed", "Active", "Recovered", "Deceased"];
  return (
    <div className="container">
      <div className="statewise-cases-table">
        <div className="table">
          <div className="row heading d-flex">
            {header.map((heading, index) => (
              <div className="cell" key={index}>
                <div>{heading}</div>
              </div>
            ))}
          </div>
          {data &&
            data.map((d, index) => (
              <React.Fragment key={index}>
                {d.statewise.map((state, index) => (
                  <React.Fragment key={index}>
                    <div className="row">
                      <div className="cell">
                        <div className="state-name">{state.state}</div>
                      </div>
                      <div className="cell statistics">
                        <div className="total">{state.confirmed}</div>
                      </div>
                      <div className="cell statistics">
                        <div className="total">{state.active}</div>
                      </div>
                      <div className="cell statistics">
                        <div className="total">{state.recovered}</div>
                      </div>
                      <div className="cell statistics">
                        <div className="total">{state.deaths}</div>
                      </div>
                    </div>
                  </React.Fragment>
                ))}
              </React.Fragment>
            ))}
        </div>
      </div>
    </div>
  );
}
